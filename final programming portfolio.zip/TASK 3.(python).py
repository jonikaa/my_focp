# Task3

import random
import sys

def generate_email(student_id, name):
  parts = name.split(", ")
  surname = parts[0]
  forenames = parts[1]

  surname = "".join([c for c in surname if c.isalpha()])

  initials = "".join([c[0] for c in forenames.split() if c[0].isalpha()])

  digits = "".join([str(random.randint(0, 9)) for _ in range(4)])

  return f"{initials.lower()}.{surname.lower()}{digits}@poppleton.ac.uk"

if len(sys.argv) < 2:
  print("Error: Missing command-line argument.")
  sys.exit(1)

input_file_name = sys.argv[1]

try:
  with open(input_file_name, "r") as input_file:
    lines = input_file.readlines()
except:
  print(f"Error: Cannot open \"{input_file_name}\". Sorry about that.")
  sys.exit(1)

emails = [(line[:8], generate_email(line[:8], line[9:])) for line in lines]

with open("emails.txt", "w") as output_file:
  for student_id, email in emails:
    output_file.write(f"{student_id} {email}\n")