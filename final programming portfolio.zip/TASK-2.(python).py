# Task2

def to_minutes_seconds(time):
    """Convert time in seconds to minutes and seconds."""
    minutes, seconds = divmod(time, 60)
    return f'{minutes} minutes, {seconds} seconds'

print('Park Run Timer\n~~~~~~~~~~~~~~')
print('\nLet\'s go!\n')

# Initialize variables for statistics
total_runners = 0
total_time = 0
fastest_time = None
slowest_time = None
best_runner = None

# Read data stream from user input
while True:
    line = input('> ')
    if line == 'END':
        break

    # Split line into runner number and time
    try:
        runner, time = line.split('::')
        runner = int(runner)
        time = int(time)
    except ValueError:
        print('Error in data stream. Ignorning. Carry on.')
        continue

    # Update statistics
    total_runners += 1
    total_time += time
    if fastest_time is None or time < fastest_time:
        fastest_time = time
        best_runner = runner
    if slowest_time is None or time > slowest_time:
        slowest_time = time

# Calculate average time
average_time = total_time // total_runners

# Print statistics
print(f'\nTotal Runners: {total_runners}')
print(f'Average Time:  {to_minutes_seconds(average_time)}')
print(f'Fastest Time:  {to_minutes_seconds(fastest_time)}')
print(f'Slowest Time:  {to_minutes_seconds(slowest_time)}')
print(f'\nBest Time Here: Runner #{best_runner}')