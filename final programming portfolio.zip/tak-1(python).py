import random

# list of words to use for passwords
WORDS = ['apple', 'banana', 'orange', 'strawberry', 'grape', 'pear', 'mango', 'watermelon', 'lemon', 'lime']
WORDS_1=['Plate','bowl','cup','kettel','mug','glass']
WORDS_2=['jacket','sweater','bottle','pants','cargo','jeans']      

print("PASSWORD GENERATOR")
print("\n")
print("==========================")
print("\n")

# prompt the user to enter the number of passwords needed
num_passwords = int(input("Enter the number of passwords needed (1-24): "))

# check that the number of passwords is within the valid range
if num_passwords < 1 or num_passwords > 24:
  print("Invalid number of passwords")
else:
  # generate and display the requested number of passwords
  for i in range(num_passwords):
    # choose three random words from the list
    password = random.choice(WORDS) + random.choice(WORDS_1) + random.choice(WORDS_2)
    print('{}---->{}'.format(i+1, password))

